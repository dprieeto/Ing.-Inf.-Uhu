#include "autobuses.h"

autobuses::autobuses()
{
    //ctor
}

autobuses::~autobuses()
{
    //dtor
}
