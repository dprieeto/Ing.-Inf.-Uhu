#ifndef AUTOBUSES_H
#define AUTOBUSES_H


class autobuses
{
    public:
        autobuses();
        virtual ~autobuses();

    protected:

    private:
};

#endif // AUTOBUSES_H
